# 🧪 Quick Test Guide

## ✅ System Status
- ✓ **Backend**: Running on `http://localhost:8080`
- ✓ **Frontend**: Running on `http://localhost:4200`
- ⚠ **AI Service**: Not running (optional - resume parsing may not work, but system will function)

---

## 🚀 Quick Test (5 Minutes)

### 1. Open Application
- Go to: **http://localhost:4200**
- You should see the **Landing Page** with role selection

### 2. Test Recruiter Flow
1. Select **"Recruiter"** → Click **"Register"**
2. Register: `recruiter@test.com` / `password123`
3. **Post a Job**:
   - Title: `Senior Java Developer`
   - Company: `Tech Corp`
   - Location: `Remote`
   - Skills: `Java, Spring Boot, REST API`
   - Description: `Looking for experienced Java developer...`
4. Click **"Post Job"** → Should see success
5. **Logout**

### 3. Test Candidate Flow
1. Select **"Candidate"** → Click **"Register"**
2. Register: `candidate@test.com` / `password123`
3. **Upload Resume** (any PDF/DOCX file)
4. Click **"Browse Available Jobs"**
5. **Verify**:
   - Jobs are displayed
   - Match scores are shown (may be 0% if AI service not running)
   - Jobs are sorted by match score
6. **Apply** for "Senior Java Developer" job
7. **Verify**: Status shows "Awaiting Response"
8. Go to **Candidate Dashboard**
9. **Verify**: Application appears in "My Applications" with "Awaiting Communication" message
10. **Logout**

### 4. Test Recruiter Review
1. Select **"Recruiter"** → Click **"Login"**
2. Login: `recruiter@test.com` / `password123`
3. Click on **"Senior Java Developer"** in "My Jobs"
4. **Verify**: Candidate appears in applicants list
5. Click **"✓ Acknowledge"** → Confirm
6. **Verify**: Status changes to "Acknowledged"
7. **Logout**

### 5. Test Status Update
1. Select **"Candidate"** → Click **"Login"**
2. Login: `candidate@test.com` / `password123`
3. Go to **Candidate Dashboard**
4. **Verify**: Application status shows **"Acknowledged"** (green badge)
5. **Verify**: Message says "Application Acknowledged: The recruiter has reviewed..."
6. Go to **Jobs page**
7. **Verify**: Job shows "Application acknowledged by recruiter"

---

## ✅ Success Criteria

- [x] Recruiter can post jobs
- [x] Candidate can upload resume
- [x] Jobs show match scores
- [x] Candidate can apply
- [x] Status shows "Awaiting communication"
- [x] Recruiter sees applications
- [x] Recruiter can acknowledge
- [x] Candidate sees updated status

---

## 🎯 Expected Visual Elements

### Job List Page
- Match score badges (percentage)
- "⭐ Best Match" badge for high matches (≥70%)
- Green left border on best matches
- Status alerts after applying

### Candidate Dashboard
- "My Applications" section
- Color-coded status badges:
  - 🔵 Blue: Awaiting Response
  - 🟢 Green: Acknowledged
  - 🔴 Red: Rejected
- Professional status messages

### Recruiter Dashboard
- Applicant cards with match scores
- Matched/Missing skills sections
- Acknowledge/Reject buttons
- Status badges

---

**All systems are ready for testing! 🚀**

