# Complete Code Explanation - JobPortal AI

## 📁 PROJECT STRUCTURE

```
JobApp/
├── backend/          # Spring Boot (Java)
├── frontend/         # Angular (TypeScript)
├── ai-service/       # Flask (Python)
└── README.md
```

---

## 🔧 BACKEND CODE EXPLANATION (Spring Boot)

### 1. **AuthController.java** - Authentication Endpoints

```java
@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    private final UserService userService;
    
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        userService.register(req);
        return ResponseEntity.ok().body(Map.of("message", "registered", "success", true));
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest req) {
        return ResponseEntity.ok(userService.loginWithUserInfo(req));
    }
    
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body(Map.of("error", "Not authenticated"));
        return ResponseEntity.ok(userService.getUserByEmail(auth.getName()));
    }
}
```

**Explanation**:
- `@RestController`: Makes this class a REST API controller
- `@RequestMapping("/auth")`: All endpoints start with `/auth`
- `@CrossOrigin`: Allows frontend (port 4200) to call backend (port 8080)
- **register**: Creates new user account, returns JSON (not plain text)
- **login**: Validates credentials, returns JWT token + user object
- **me**: Returns current logged-in user info

---

### 2. **JobController.java** - Job Management

```java
@RestController
@RequestMapping("/jobs")
public class JobController {
    private final JobService jobService;
    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    
    @GetMapping
    public Page<Job> search(@RequestParam(value = "q", required = false) String q,
                           @RequestParam(value = "page", defaultValue = "0") int page,
                           @RequestParam(value = "size", defaultValue = "10") int size) {
        return jobService.search(q, PageRequest.of(page, size, Sort.by("createdAt").descending()));
    }
    
    @PostMapping
    public ResponseEntity<?> create(@RequestBody JobDto dto, Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body("Unauthorized");
        var user = userRepository.findByEmail(auth.getName()).orElseThrow();
        
        Job j = new Job();
        j.setTitle(dto.getTitle());
        j.setCompany(dto.getCompany());
        j.setSkills(dto.getSkills());  // IMPORTANT: Used for matching
        j.setRecruiterId(user.getId());
        
        return ResponseEntity.ok(jobService.create(j));
    }
    
    @GetMapping("/my")
    public ResponseEntity<?> myJobs(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body("Unauthorized");
        var user = userRepository.findByEmail(auth.getName()).orElseThrow();
        return ResponseEntity.ok(jobRepository.findByRecruiterId(user.getId()));
    }
}
```

**Explanation**:
- **search**: Returns paginated job list, sorted by newest first
- **create**: Creates job, automatically sets recruiterId from logged-in user
- **myJobs**: Returns only jobs posted by current recruiter
- `Authentication auth`: Spring Security automatically injects current user

---

### 3. **ApplicationService.java** - AI Ranking Logic ⭐

```java
@Service
public class ApplicationService {
    @Autowired private ApplicationRepository applicationRepository;
    @Autowired private ResumeRepository resumeRepository;
    @Autowired private UserRepository userRepository;
    
    public List<ApplicationDTO> listByJob(Long jobId) {
        List<Application> apps = applicationRepository.findByJobId(jobId);
        Job job = jobRepository.findById(jobId).orElseThrow();
        
        return apps.stream().map(app -> {
            Resume resume = resumeRepository.findById(app.getResumeId()).orElse(null);
            User user = userRepository.findById(app.getUserId()).orElse(null);
            
            // Calculate match score
            double score = computeMatchScore(job.getSkills(), resume != null ? resume.getParsedJson() : null);
            app.setMatchScore(score);
            applicationRepository.save(app);
            
            return new ApplicationDTO(app, resume, user);
        })
        .sorted((a, b) -> Double.compare(b.getApplication().getMatchScore(), 
                                         a.getApplication().getMatchScore()))
        .collect(Collectors.toList());
    }
    
    private double computeMatchScore(String jobSkillsCsv, String parsedJson) {
        if (jobSkillsCsv == null || parsedJson == null) return 0.0;
        
        // Split job skills: "Java, Python, React" -> ["java", "python", "react"]
        String[] required = Arrays.stream(jobSkillsCsv.split(","))
                .map(String::trim)
                .map(String::toLowerCase)
                .toArray(String[]::new);
        
        // Count how many required skills are in the resume JSON
        int matched = 0;
        String lowerJson = parsedJson.toLowerCase();
        for (String skill : required) {
            if (lowerJson.contains(skill)) matched++;
        }
        
        // Calculate percentage
        return required.length == 0 ? 0.0 : (double) matched / required.length * 100;
    }
}
```

**Explanation** (THIS IS THE AI RANKING ALGORITHM):
1. Get all applications for a job
2. For each application:
   - Fetch resume (contains parsed JSON)
   - Fetch user info
   - **Calculate match score**: Compare job skills vs resume skills
3. Sort by match score (highest first)
4. Return ApplicationDTO with all data

**Match Score Formula**:
```
Score = (Number of Matched Skills / Total Required Skills) × 100

Example:
Job requires: Java, Python, React, AWS (4 skills)
Candidate has: Java, Python, Angular, Docker (2 match)
Score = (2 / 4) × 100 = 50%
```

---

### 4. **ResumeService.java** - AI Integration

```java
@Service
public class ResumeService {
    @Value("${ai.resume.parser.url:http://localhost:5001}")
    private String aiParserUrl;
    
    @Autowired private RestTemplate restTemplate;
    @Autowired private ResumeRepository resumeRepository;
    
    public Resume saveResume(MultipartFile file, Long userId) throws Exception {
        // 1. Save file to disk
        String uploadDir = "uploads/";
        new File(uploadDir).mkdirs();
        String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        String filepath = uploadDir + filename;
        file.transferTo(new File(filepath));
        
        // 2. Call AI service to parse
        Map<String, Object> parsed = parseResume(file);
        
        // 3. Save to database
        Resume resume = new Resume();
        resume.setUserId(userId);
        resume.setFileUrl(filepath);
        resume.setParsedJson(new ObjectMapper().writeValueAsString(parsed));
        resume.setUploadedAt(LocalDateTime.now());
        
        return resumeRepository.save(resume);
    }
    
    public Map<String, Object> parseResume(MultipartFile file) throws Exception {
        // Prepare file for AI service
        ByteArrayResource fileAsResource = new ByteArrayResource(file.getBytes()) {
            @Override
            public String getFilename() {
                return file.getOriginalFilename();
            }
        };
        
        // Create multipart request
        LinkedMultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileAsResource);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        
        HttpEntity<LinkedMultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);
        
        // Call Python AI service
        ResponseEntity<Map> response = restTemplate.exchange(
            aiParserUrl + "/parse",
            HttpMethod.POST,
            request,
            Map.class
        );
        
        return response.getBody();
    }
}
```

**Explanation**:
1. **saveResume**: 
   - Saves PDF file to `uploads/` folder
   - Calls AI service to parse it
   - Stores parsed JSON in database
2. **parseResume**: 
   - Sends PDF to Python AI service (port 5001)
   - Receives JSON with name, email, skills
   - Returns to caller

---

## 🎨 FRONTEND CODE EXPLANATION (Angular)

### 1. **app.component.ts** - Main Navigation

```typescript
export class AppComponent implements OnInit {
  isDark = false;
  currentUser: User | null = null;
  
  constructor(
    private themeService: ThemeService,
    private authService: AuthService,
    private router: Router
  ) {
    this.themeService.isDark$.subscribe(isDark => this.isDark = isDark);
  }
  
  ngOnInit() {
    // Subscribe to user changes
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    
    // Track route changes
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
      });
  }
  
  toggleTheme() {
    this.themeService.toggleTheme();
  }
  
  logout() {
    this.authService.logout();
    window.location.href = '/';
  }
}
```

**Explanation**:
- **currentUser**: Stores logged-in user (null if not logged in)
- **ngOnInit**: Runs when app starts, subscribes to user and route changes
- **toggleTheme**: Switches between dark/light mode
- **logout**: Clears user data and redirects to home

---

### 2. **auth.service.ts** - Authentication State

```typescript
@Injectable({ providedIn: 'root' })
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  
  constructor(private api: ApiService) {
    this.loadUserFromStorage();
  }
  
  private loadUserFromStorage() {
    if (typeof window !== 'undefined') {
      const userStr = localStorage.getItem('user');
      const token = localStorage.getItem('token');
      if (userStr && token) {
        const user = JSON.parse(userStr);
        this.currentUserSubject.next(user);
      }
    }
  }
  
  setUser(user: User, token: string) {
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('token', token);
    this.currentUserSubject.next(user);
  }
  
  logout() {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    this.currentUserSubject.next(null);
  }
}
```

**Explanation**:
- **BehaviorSubject**: Reactive state management (components auto-update when user changes)
- **loadUserFromStorage**: On app start, check if user was logged in before
- **setUser**: Save user + token after login
- **logout**: Clear everything

---

### 3. **login.component.ts** - Login Logic

```typescript
export class LoginComponent implements OnInit {
  email = '';
  password = '';
  selectedRole: string = '';
  
  ngOnInit() {
    // Get role from URL: /login?role=ROLE_RECRUITER
    this.route.queryParams.subscribe(params => {
      this.selectedRole = params['role'] || '';
      if (this.selectedRole === 'ROLE_RECRUITER') {
        this.roleLabel = 'Recruiter';
        this.roleIcon = '💼';
      } else {
        this.roleLabel = 'Candidate';
        this.roleIcon = '👤';
      }
    });
  }
  
  doLogin() {
    this.api.post('/auth/login', { email: this.email, password: this.password })
      .subscribe({
        next: (res: any) => {
          const token = res.token;
          const user = res.user;
          this.authService.setUser(user, token);
          
          // Navigate based on ACTUAL role (not query param)
          if (user.role === 'ROLE_RECRUITER') {
            this.router.navigate(['/recruiter']);
          } else {
            this.router.navigate(['/candidate']);
          }
        },
        error: (err) => {
          alert('Login failed: ' + err.error.message);
        }
      });
  }
}
```

**Explanation**:
- **selectedRole**: From URL query param (for UI display only)
- **doLogin**: 
  1. Send credentials to backend
  2. Receive token + user object
  3. Save to localStorage via AuthService
  4. Redirect based on user's ACTUAL role

---

### 4. **recruiter-dashboard.component.ts** - Job Posting & Applicant View

```typescript
export class RecruiterDashboardComponent {
  jobs: any[] = [];
  selectedJob: any = null;
  applicants: any[] = [];
  
  constructor(private api: ApiService) {
    this.loadMyJobs();
  }
  
  loadMyJobs() {
    this.api.get('/jobs/my').subscribe((r: any) => this.jobs = r);
  }
  
  postJob() {
    this.api.post('/jobs', { 
      title: this.title, 
      company: this.company, 
      skills: this.skills,  // IMPORTANT for matching
      description: this.desc 
    }).subscribe(r => {
      alert('Job posted');
      this.loadMyJobs();
    });
  }
  
  viewApplicants(job: any) {
    this.selectedJob = job;
    this.api.get(`/applications/job/${job.id}`).subscribe((apps: any) => {
      this.applicants = (apps as any[]).map(app => {
        // Analyze skills on frontend for display
        app.analysis = this.analyzeSkills(job.skills, app.resume?.parsedJson);
        return app;
      });
    });
  }
  
  analyzeSkills(jobSkills: string, resumeJson: string) {
    if (!jobSkills || !resumeJson) return { matched: [], missing: [] };
    
    const required = jobSkills.split(',').map(s => s.trim().toLowerCase());
    let parsed: any = {};
    try { parsed = JSON.parse(resumeJson); } catch(e) {}
    
    const candidateSkills = (parsed.skills || []).map((s:string) => s.toLowerCase());
    
    const matched = required.filter(r => candidateSkills.includes(r));
    const missing = required.filter(r => !candidateSkills.includes(r));
    
    return { matched, missing };
  }
}
```

**Explanation**:
- **loadMyJobs**: Gets recruiter's posted jobs
- **postJob**: Creates new job with required skills
- **viewApplicants**: 
  1. Gets applicants (already sorted by match score from backend)
  2. Analyzes skills for UI display (green/red badges)
- **analyzeSkills**: Splits skills into "matched" and "missing" arrays

---

## 🤖 AI SERVICE CODE EXPLANATION (Python Flask)

### **app.py** - Resume Parser

```python
from flask import Flask, request, jsonify
import pdfplumber
import re

app = Flask(__name__)

def extract_text_from_pdf(file):
    """Extract all text from PDF"""
    with pdfplumber.open(file) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text() + "\n"
    return text

def extract_email(text):
    """Find email using regex"""
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    match = re.search(email_pattern, text)
    return match.group(0) if match else None

def extract_phone(text):
    """Find phone number using regex"""
    phone_patterns = [
        r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
        r'\d{3}[-.\s]\d{3}[-.\s]\d{4}',
    ]
    for pattern in phone_patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(0)
    return None

def extract_skills(text):
    """Match skills from predefined list"""
    common_skills = [
        "Java", "Python", "JavaScript", "TypeScript", "Angular", "React",
        "Spring Boot", "Node.js", "MongoDB", "PostgreSQL", "AWS", "Docker",
        "Kubernetes", "Git", "CI/CD", "Machine Learning", "AI"
    ]
    found_skills = []
    for skill in common_skills:
        # Case-insensitive word boundary search
        if re.search(r'\b' + re.escape(skill) + r'\b', text, re.IGNORECASE):
            found_skills.append(skill)
    return found_skills

@app.route('/parse', methods=['POST'])
def parse_resume():
    """Main endpoint: receives PDF, returns JSON"""
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    try:
        # 1. Extract text from PDF
        text = extract_text_from_pdf(file)
        
        # 2. Extract entities
        email = extract_email(text)
        phone = extract_phone(text)
        skills = extract_skills(text)
        
        # 3. Extract name (first non-empty line)
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        name = lines[0] if lines else "Unknown"
        
        # 4. Return JSON
        return jsonify({
            "name": name,
            "email": email,
            "phone": phone,
            "skills": skills,
            "experience": [],
            "education": [],
            "certifications": []
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5001, debug=True)
```

**Explanation**:
1. **extract_text_from_pdf**: Uses pdfplumber to read PDF and extract all text
2. **extract_email**: Regex pattern matches email format
3. **extract_phone**: Multiple regex patterns for different phone formats
4. **extract_skills**: Checks if any skill from list appears in text (case-insensitive)
5. **parse_resume**: Main endpoint that orchestrates everything

**How it works**:
```
PDF File → pdfplumber → Raw Text → Regex Patterns → Structured JSON
```

---

## 🔐 SECURITY FEATURES

### 1. **JWT Authentication**
```java
// In SecurityConfig.java
http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
```
- Every API request includes: `Authorization: Bearer <token>`
- Backend validates token before processing request

### 2. **Password Hashing**
```java
// In UserService.java
String hashedPassword = passwordEncoder.encode(plainPassword);
```
- Uses BCrypt (one-way hash, cannot be reversed)
- Even if database is compromised, passwords are safe

### 3. **CORS Protection**
```java
@CrossOrigin(origins = "*")  // In production: specify exact frontend URL
```
- Prevents unauthorized websites from calling your API

---

## 📊 DATA FLOW EXAMPLE

### Scenario: Candidate Applies to Job

```
1. Candidate uploads resume (PDF)
   ↓
2. Frontend → POST /api/resume/upload
   ↓
3. Backend saves file to uploads/
   ↓
4. Backend → POST http://localhost:5001/parse (with PDF)
   ↓
5. AI Service extracts: name, email, skills
   ↓
6. AI Service → Returns JSON
   ↓
7. Backend saves JSON to database (resumes table)
   ↓
8. Candidate applies to job
   ↓
9. Backend creates application record
   ↓
10. Recruiter views applicants
   ↓
11. Backend calculates match scores
   ↓
12. Frontend displays ranked list with badges
```

---

## 🎯 KEY CONCEPTS TO EXPLAIN

### 1. **Microservices Architecture**
- Backend, Frontend, AI Service are separate
- Can scale independently
- AI service uses Python (better for ML/PDF processing)

### 2. **RESTful API**
- Stateless communication
- HTTP methods: GET (read), POST (create), PUT (update), DELETE (remove)
- JSON data format

### 3. **Reactive Programming (RxJS)**
```typescript
this.authService.currentUser$.subscribe(user => {
  this.currentUser = user;  // Auto-updates when user changes
});
```

### 4. **Dependency Injection**
```java
@Autowired
private UserRepository userRepository;  // Spring automatically provides instance
```

---

## ✅ TESTING CHECKLIST

Before presentation, verify:
- [ ] Can register as recruiter
- [ ] Can post job with skills
- [ ] Can register as candidate
- [ ] Can upload resume (use sample_resume.pdf)
- [ ] Resume shows parsed skills in network tab
- [ ] Can apply to job
- [ ] Recruiter sees applicant with match score
- [ ] Green/red skill badges display correctly
- [ ] Dark mode toggle works
- [ ] Logout and login again works

---

**You now have complete understanding of every part of the code!** 🎓
