# JobPortal AI - Final Exam Presentation Guide

## 🎯 Quick Overview
**JobPortal AI** is a full-stack job portal with AI-powered resume parsing and candidate ranking. It helps recruiters find the best candidates and helps job seekers find opportunities.

---

## 🚀 HOW TO START THE APPLICATION

### Step 1: Start AI Service (Python)
```bash
# Open Terminal 1
cd C:\Users\Shubh Kaushik\Desktop\JobApp\ai-service
python app.py
```
**Expected Output**: `Running on http://127.0.0.1:5001`

### Step 2: Start Backend (Java/Spring Boot)
```bash
# Open Terminal 2
cd C:\Users\Shubh Kaushik\Desktop\JobApp\backend
mvn spring-boot:run
```
**Expected Output**: `Started JobPortalApplication on port 8080`

### Step 3: Start Frontend (Angular)
```bash
# Open Terminal 3
cd C:\Users\Shubh Kaushik\Desktop\JobApp\frontend
ng serve
```
**Expected Output**: `Application bundle generation complete`

### Step 4: Open Browser
Navigate to: **http://localhost:4200**

---

## 🏗️ ARCHITECTURE OVERVIEW

### Three-Tier Architecture

```
┌─────────────────┐
│   Frontend      │  Angular (Port 4200)
│   (Angular)     │  - User Interface
└────────┬────────┘  - Dark/Light Mode
         │           - Role-based Views
         ↓
┌─────────────────┐
│   Backend       │  Spring Boot (Port 8080)
│ (Spring Boot)   │  - REST APIs
└────────┬────────┘  - Authentication (JWT)
         │           - Business Logic
         ↓
┌─────────────────┐
│  AI Service     │  Flask (Port 5001)
│   (Python)      │  - Resume Parsing
└─────────────────┘  - Skill Extraction
         │
         ↓
┌─────────────────┐
│   Database      │  MySQL (Port 3306)
│    (MySQL)      │  - User Data
└─────────────────┘  - Jobs, Applications
```

---

## 🎨 KEY FEATURES TO DEMONSTRATE

### 1. Landing Page & Role Selection
**What to Show**:
- Beautiful landing page with role cards
- Click "Candidate" or "Recruiter" card
- Login/Register buttons appear

**What to Say**:
> "The application has role-based authentication. Users first select whether they are a Candidate looking for jobs or a Recruiter hiring talent. This ensures proper access control."

### 2. User Registration
**What to Show**:
- Register as Recruiter with sample data:
  - Name: "Sarah Johnson"
  - Email: "sarah@techcorp.com"
  - Password: "password123"
- Auto-login and redirect to recruiter dashboard

**What to Say**:
> "Registration is role-specific. Once registered, the role is permanent and cannot be changed. After registration, users are automatically logged in and redirected to their dashboard."

### 3. Recruiter Dashboard - Post Job
**What to Show**:
- Fill job posting form:
  - Title: "Senior Full Stack Developer"
  - Company: "Tech Corp"
  - Location: "Remote"
  - Skills: "Java, Spring Boot, React, AWS"
  - Description: "Looking for experienced developer..."
- Submit and see job in "My Jobs" list

**What to Say**:
> "Recruiters can post jobs with required skills. The skills field is crucial because our AI uses it to match candidates. Notice the modern UI with smooth animations and dark mode support."

### 4. AI Resume Parsing (★ KEY FEATURE)
**What to Show**:
- Register/Login as Candidate
- Upload the sample resume (`ai-service/sample_resume.pdf`)
- Show parsed data in console/network tab

**What to Say**:
> "This is our AI-powered resume parser. When candidates upload their resume, our Python Flask service uses pdfplumber to extract text and then uses pattern matching to identify:
> - Name: John Michael Smith
> - Email: john.smith@email.com
> - Skills: Java, Python, JavaScript, Spring Boot, React, etc.
> 
> The AI found 15 skills automatically! This data is stored in JSON format in the database."

### 5. Candidate Ranking (★ KEY FEATURE)
**What to Show**:
- As recruiter, click on posted job
- View applicants list
- Point out Match Score percentage
- Show matched vs missing skills

**What to Say**:
> "This is the AI-powered candidate ranking system. The backend calculates a Match Score by comparing:
> - Job's required skills: Java, Spring Boot, React, AWS
> - Candidate's parsed skills from their resume
> 
> Match Score = (Matched Skills / Required Skills) × 100
> 
> Green badges show matched skills, red badges show missing skills. This helps recruiters quickly identify the best candidates."

### 6. Dark/Light Mode
**What to Show**:
- Click sun/moon icon in navbar
- Show smooth theme transition

**What to Say**:
> "The application features a modern design system with dark and light modes. The theme preference is saved in localStorage and persists across sessions."

---

## 💻 TECHNICAL STACK

### Frontend
- **Framework**: Angular 18
- **Language**: TypeScript
- **Styling**: Custom CSS with CSS Variables
- **Features**: 
  - Standalone components
  - Reactive forms
  - RxJS for state management
  - Dark/light mode theming

### Backend
- **Framework**: Spring Boot 3.x
- **Language**: Java 11
- **Security**: Spring Security + JWT
- **Database**: MySQL with JPA/Hibernate
- **APIs**: RESTful endpoints

### AI Service
- **Framework**: Flask (Python)
- **Libraries**: 
  - pdfplumber (PDF text extraction)
  - Regular expressions (pattern matching)
- **Functionality**: Resume parsing, skill extraction

---

## 🔐 AUTHENTICATION FLOW

```
1. User visits landing page (/)
   ↓
2. Selects role (Candidate/Recruiter)
   ↓
3. Registers with role parameter
   ↓
4. Backend creates user with role in database
   ↓
5. Auto-login returns JWT token + user object
   ↓
6. Frontend stores token in localStorage
   ↓
7. All API requests include JWT in Authorization header
   ↓
8. Backend validates token and checks role
```

---

## 📊 DATABASE SCHEMA

### Key Tables:
- **users**: id, name, email, password (BCrypt), role
- **jobs**: id, title, company, location, skills, description, recruiterId
- **applications**: id, jobId, userId, resumeId, matchScore, status
- **resumes**: id, userId, fileUrl, parsedJson, uploadedAt

---

## 🎯 AI ALGORITHM EXPLANATION

### Resume Parsing Algorithm:
```python
1. Receive PDF file via HTTP POST
2. Extract text using pdfplumber
3. Apply regex patterns:
   - Email: [A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}
   - Phone: \+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}
   - Name: First non-empty line
4. Match skills against predefined list (case-insensitive)
5. Return JSON with extracted data
```

### Candidate Ranking Algorithm:
```java
1. Get job's required skills (comma-separated)
2. Get candidate's parsed skills (from JSON)
3. Convert both to lowercase arrays
4. Count matched skills
5. Calculate: matchScore = (matched / required) × 100
6. Sort applicants by matchScore (descending)
7. Return ApplicationDTO with analysis
```

---

## 🎬 DEMONSTRATION SCRIPT

### Opening (30 seconds)
> "Good morning/afternoon. Today I'm presenting JobPortal AI, a modern job portal with artificial intelligence features. The application has three main components: an Angular frontend, a Spring Boot backend, and a Python AI service for resume parsing."

### Feature Demo (3-4 minutes)
1. **Show landing page** (20 sec)
   - "Users select their role first"
   
2. **Register as Recruiter** (30 sec)
   - "Role-based registration with validation"
   
3. **Post a Job** (40 sec)
   - "Recruiters specify required skills"
   
4. **Register as Candidate & Upload Resume** (60 sec)
   - "AI automatically extracts skills from PDF"
   - Show network tab with parsed JSON
   
5. **View Ranked Applicants** (60 sec)
   - "AI calculates match scores"
   - "Green = matched skills, Red = missing skills"
   
6. **Show Dark Mode** (20 sec)
   - "Modern UI with theme support"

### Technical Explanation (1-2 minutes)
> "The architecture uses microservices. The frontend communicates with the backend via REST APIs. When a resume is uploaded, the backend forwards it to the Python AI service, which returns parsed data. This data is stored as JSON and used for calculating match scores when recruiters view applicants."

### Closing (20 seconds)
> "This application demonstrates full-stack development with AI integration, role-based authentication, and modern UI/UX principles. Thank you."

---

## 🔧 TROUBLESHOOTING

### If AI Service Fails:
- Check: `http://localhost:5001` is accessible
- Restart: `python app.py` in ai-service folder

### If Backend Fails:
- Check: MySQL is running on port 3306
- Check: `application.properties` has correct DB credentials

### If Frontend Fails:
- Run: `npm install` if node_modules missing
- Check: Port 4200 is not in use

---

## 📝 QUESTIONS YOU MIGHT BE ASKED

**Q: Why use a separate AI service?**
> "Separation of concerns. Python has better libraries for PDF processing (pdfplumber) and ML. This microservice architecture allows us to scale the AI service independently."

**Q: How is the match score calculated?**
> "It's a simple percentage: (number of matched skills / total required skills) × 100. For example, if a job requires 5 skills and candidate has 4 of them, the score is 80%."

**Q: Is the password secure?**
> "Yes, we use BCrypt hashing through Spring Security. Passwords are never stored in plain text."

**Q: Can a candidate become a recruiter?**
> "No, roles are immutable. They're set during registration and stored in the database. This ensures data integrity."

**Q: What happens if the AI service is down?**
> "The resume upload would fail gracefully with an error message. In production, we'd implement retry logic and fallback mechanisms."

---

## ✅ FINAL CHECKLIST

Before Presentation:
- [ ] All three services running (AI, Backend, Frontend)
- [ ] Browser open to http://localhost:4200
- [ ] Sample resume ready (`ai-service/sample_resume.pdf`)
- [ ] Test data prepared (recruiter and candidate accounts)
- [ ] Network tab open in browser (to show API calls)
- [ ] Dark mode tested
- [ ] Practiced demo flow (5-7 minutes total)

---

## 🎓 GOOD LUCK!

**Remember**: 
- Speak clearly and confidently
- Explain the "why" not just the "what"
- Show the AI features - they're your differentiator
- If something breaks, explain what should happen
- Smile and make eye contact!

**You've got this!** 🚀
