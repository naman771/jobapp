# Job Portal System Testing Guide

## 🧪 Complete Testing Flow

### Prerequisites Check
1. **Backend** should be running on `http://localhost:8080`
2. **Frontend** should be running on `http://localhost:4200`
3. **AI Service** (optional) should be running on `http://localhost:5001` for resume parsing

---

## 📋 Step-by-Step Test Flow

### Phase 1: Recruiter Setup

#### Step 1: Access the Application
1. Open browser and navigate to `http://localhost:4200`
2. You should see the **Landing Page** with role selection

#### Step 2: Register as Recruiter
1. Select **"Recruiter"** role
2. Click **"Register"**
3. Fill in:
   - Name: `John Recruiter`
   - Email: `recruiter@test.com`
   - Password: `password123`
4. Click **"Register"**
5. Should automatically login and redirect to Recruiter Dashboard

#### Step 3: Post a Job
1. On Recruiter Dashboard, fill in job details:
   - **Job Title**: `Senior Java Developer`
   - **Company**: `Tech Corp`
   - **Location**: `Remote`
   - **Required Skills**: `Java, Spring Boot, REST API, MySQL`
   - **Job Description**: `We are looking for an experienced Java developer with Spring Boot expertise...`
2. Click **"Post Job"**
3. Should see success message: "Job posted"
4. Job should appear in "My Jobs" section on the left

#### Step 4: Post Another Job (for testing recommendations)
1. Post another job:
   - **Job Title**: `Python Developer`
   - **Company**: `Data Inc`
   - **Location**: `New York`
   - **Required Skills**: `Python, Django, PostgreSQL`
   - **Job Description**: `Looking for Python developer...`
2. Click **"Post Job"**

#### Step 5: Logout
1. Click **"Logout"** in the navbar
2. Should return to Landing Page

---

### Phase 2: Candidate Application

#### Step 6: Register as Candidate
1. Select **"Candidate"** role
2. Click **"Register"**
3. Fill in:
   - Name: `Jane Candidate`
   - Email: `candidate@test.com`
   - Password: `password123`
4. Click **"Register"**
5. Should automatically login and redirect to Candidate Dashboard

#### Step 7: Upload Resume
1. On Candidate Dashboard, click **"Select Resume File"**
2. Upload a resume file (PDF or DOCX)
   - **Note**: If AI service is not running, upload will still work but parsing may fail
   - For testing, create a simple resume mentioning: `Java, Spring Boot, REST API`
3. Click **"Upload Resume"**
4. Should see success message: "Resume uploaded successfully"

#### Step 8: Browse Jobs with Recommendations
1. Click **"Browse Available Jobs"** button or navigate to `/jobs`
2. **Expected Behavior**:
   - Jobs should be displayed with **match scores** (percentage badges)
   - Jobs should be **sorted by match score** (best matches first)
   - Jobs with ≥70% match should have:
     - Green left border
     - "⭐ Best Match" badge
   - The "Senior Java Developer" job should show high match if resume contains Java/Spring Boot
   - The "Python Developer" job should show lower match

#### Step 9: Apply for a Job
1. Find the **"Senior Java Developer"** job (should be recommended first if resume matches)
2. Click **"Apply Now"** button
3. Should see success message: "Application submitted successfully! Awaiting communication from the recruiter."
4. The job card should now show:
   - **Status badge**: "Awaiting Response"
   - **Alert message**: "⏳ Awaiting Communication: Your application has been submitted successfully..."

#### Step 10: Check Application Status
1. Go back to Candidate Dashboard (`/candidate`)
2. Scroll down to **"My Applications"** section
3. Should see:
   - Job title: "Senior Java Developer"
   - Company: "Tech Corp"
   - Status: "Awaiting Response" (blue badge)
   - Match Score: percentage badge
   - Alert message: "⏳ Awaiting Communication: Your application has been submitted successfully..."

#### Step 11: Logout
1. Click **"Logout"** in the navbar

---

### Phase 3: Recruiter Review

#### Step 12: Login as Recruiter
1. Select **"Recruiter"** role
2. Click **"Login"**
3. Enter:
   - Email: `recruiter@test.com`
   - Password: `password123`
4. Click **"Sign In"**
5. Should redirect to Recruiter Dashboard

#### Step 13: View Applicants
1. In "My Jobs" section, click on **"Senior Java Developer"** job
2. Should see applicant section on the right
3. **Expected to see**:
   - Candidate name: "Jane Candidate"
   - Candidate email: `candidate@test.com`
   - Match Score badge (e.g., "Match: 75%")
   - Status badge: "New Application" (blue)
   - **Matched Skills** section (green badges): Skills that match
   - **Missing Skills** section (red badges): Skills that don't match
   - **"View Resume"** button
   - **"✓ Acknowledge"** button (green)
   - **"✗ Reject"** button (red)

#### Step 14: Acknowledge Application
1. Click **"✓ Acknowledge"** button
2. Confirm the dialog: "Are you sure you want to acknowledge this application?"
3. Should see success message: "Application acknowledged successfully. The candidate will be notified."
4. Status should change to:
   - Badge: "Acknowledged" (green)
   - Buttons should disappear
   - Text: "Status: Acknowledged"

#### Step 15: Logout
1. Click **"Logout"**

---

### Phase 4: Candidate Status Update

#### Step 16: Login as Candidate
1. Select **"Candidate"** role
2. Click **"Login"**
3. Enter:
   - Email: `candidate@test.com`
   - Password: `password123`
4. Click **"Sign In"**

#### Step 17: Check Updated Status
1. Go to Candidate Dashboard
2. In **"My Applications"** section, should see:
   - Status badge changed to: **"Acknowledged"** (green)
   - Alert message changed to: **"✓ Application Acknowledged: The recruiter has reviewed and acknowledged your application. You may be contacted for further steps in the hiring process."**
3. Go to Jobs page (`/jobs`)
4. The "Senior Java Developer" job should show:
   - Status: "Acknowledged" (green badge)
   - Message: "✓ Application acknowledged by recruiter"

---

### Phase 5: Test Rejection Flow (Optional)

#### Step 18: Test Rejection
1. Logout as Candidate
2. Login as Recruiter
3. Post another job
4. Logout and Login as Candidate
5. Apply for the new job
6. Logout and Login as Recruiter
7. View applicants for the new job
8. Click **"✗ Reject"** button
9. Confirm rejection
10. Logout and Login as Candidate
11. Should see rejection status with red badge and message

---

## ✅ Expected Results Summary

### Job Recommendations
- ✅ Jobs sorted by match score (highest first)
- ✅ Match percentage displayed for each job
- ✅ Best matches (≥70%) highlighted with green border and star badge

### Application Status Flow
- ✅ **APPLIED**: Blue badge, "Awaiting Response"
- ✅ **ACKNOWLEDGED**: Green badge, "Acknowledged"
- ✅ **REJECTED**: Red badge, "Not Selected"

### Professional Messages
- ✅ Clear status messages for each state
- ✅ Professional tone in all communications
- ✅ Color-coded badges for quick status identification

---

## 🐛 Troubleshooting

### Backend not responding
- Check if backend is running: `http://localhost:8080/jobs`
- Restart: `cd backend; mvn spring-boot:run`

### Frontend not loading
- Check if frontend is running: `http://localhost:4200`
- Restart: `cd frontend; ng serve`

### Resume parsing fails
- Check if AI service is running: `http://localhost:5001`
- Start: `cd ai-service; python app.py`
- Note: Application will still work, but match scores may be 0%

### No match scores shown
- Ensure resume is uploaded first
- Check that resume contains skills mentioned in job postings
- Verify AI service is running for proper parsing

### Applications not appearing
- Ensure you're logged in as the correct role
- Check that you clicked on the correct job in recruiter dashboard
- Use "Refresh" button if needed

---

## 📊 Test Checklist

- [ ] Recruiter can register and login
- [ ] Recruiter can post jobs
- [ ] Candidate can register and login
- [ ] Candidate can upload resume
- [ ] Jobs are displayed with match scores
- [ ] Jobs are sorted by match score (best first)
- [ ] Best matches are highlighted
- [ ] Candidate can apply for jobs
- [ ] Application shows "Awaiting communication" status
- [ ] Recruiter can see applications
- [ ] Recruiter can acknowledge application
- [ ] Recruiter can reject application
- [ ] Candidate sees updated status after acknowledge
- [ ] Candidate sees updated status after reject
- [ ] Status messages are professional and clear
- [ ] UI is clean and professional

---

**Happy Testing! 🚀**

