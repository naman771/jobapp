# Job Portal Application

## Prerequisites
- **Java 17+** (for Backend)
- **Node.js 18+** & **npm** (for Frontend)
- **Python 3.10+** (for AI Service)
- **Angular CLI** (`npm install -g @angular/cli`)
- **MySQL** (Running on port 3306)

## Database Setup
1. Create a database named `jobportal`.
2. The application is configured to use `root` / `admin` as credentials.
3. Update `backend/src/main/resources/application.properties` if your credentials differ.

## Running the Backend
1. Navigate to the `backend` directory:
   ```bash
   cd backend
   ```
2. Run the application using Maven Wrapper:
   ```bash
   ./mvnw spring-boot:run
   ```
   (On Windows Command Prompt, use `mvnw spring-boot:run`)

The backend will start on `http://localhost:8080`.

## Running the Frontend
1. Navigate to the `frontend` directory:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   ng serve
   ```
   
The frontend will be available at `http://localhost:4200`.

## Running the AI Service
1. Navigate to the `ai-service` directory:
   ```bash
   cd ai-service
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the Flask app:
   ```bash
   python app.py
   ```
The service will start on `http://localhost:5001`.

## Notes
- **AI Resume Parser**: Ensure the Python service is running for resume parsing to work.
