import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-job-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
  <div class="container fade-in">
    <div style="text-align: center; margin-bottom: 4rem;">
      <h1 style="margin-bottom: 1rem;">Discover Opportunities</h1>
      <p class="text-secondary" style="font-size: 1.125rem; max-width: 600px; margin: 0 auto;">
        <span *ngIf="isLoggedIn">Jobs recommended for you based on your resume</span>
        <span *ngIf="!isLoggedIn">Find your next career move from thousands of job listings</span>
      </p>
    </div>
    <div *ngIf="jobs.length===0" class="alert alert-info" style="text-align: center;">
      <p style="margin: 0;">No jobs available at the moment. Check back soon!</p>
    </div>
    <div class="row">
      <div *ngFor="let jobItem of jobs; let i = index" class="col-md-6 mb-4">
        <div class="card h-100 slide-up" [style.animation-delay]="i * 0.1 + 's'" 
             [style.border-left]="isLoggedIn && jobItem.matchScore >= 70 ? '4px solid #10b981' : 'none'">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="flex-grow-1">
              <div class="d-flex align-items-center gap-2 mb-2">
                <h3 class="mb-0 text-primary" style="font-size: 1.5rem;">{{jobItem.job?.title || jobItem.title}}</h3>
                <span *ngIf="isLoggedIn && jobItem.matchScore >= 70" class="badge bg-success" style="font-size: 0.75rem;">
                  ⭐ Best Match
                </span>
              </div>
              <div *ngIf="isLoggedIn" class="mb-2">
                <span class="badge" 
                      [class.bg-success]="jobItem.matchScore >= 70"
                      [class.bg-warning]="jobItem.matchScore >= 40 && jobItem.matchScore < 70"
                      [class.bg-secondary]="jobItem.matchScore < 40"
                      style="font-size: 0.875rem;">
                  Match: {{jobItem.matchScore | number:'1.0-0'}}%
                </span>
              </div>
            </div>
            <span class="badge bg-light text-dark border" style="white-space: nowrap;">
              {{(jobItem.job?.jobType || jobItem.jobType) || 'Full-time'}}
            </span>
          </div>
          <div class="text-muted mb-4" style="font-size: 1rem;">
            <strong>{{jobItem.job?.company || jobItem.company}}</strong> • {{jobItem.job?.location || jobItem.location}}
          </div>
          <p class="text-secondary flex-grow-1" style="margin-bottom: 2rem; line-height: 1.7;">
            {{jobItem.job?.description || jobItem.description}}
          </p>
          <div *ngIf="(jobItem.job?.skills || jobItem.skills)" class="d-flex flex-wrap gap-2 mb-4">
            <span *ngFor="let s of (jobItem.job?.skills || jobItem.skills).split(',')" 
                  class="badge bg-primary bg-opacity-10 text-primary" 
                  style="padding: 0.5rem 1rem; font-size: 0.875rem;">{{s.trim()}}</span>
          </div>
          <div *ngIf="getApplicationStatus(jobItem.job?.id || jobItem.id)" class="mb-3">
            <div class="alert" 
                 [class.alert-info]="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'APPLIED'"
                 [class.alert-success]="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'ACKNOWLEDGED'"
                 [class.alert-danger]="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'REJECTED'"
                 style="padding: 0.75rem; margin: 0;">
              <small>
                <strong *ngIf="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'APPLIED'">
                  ⏳ Awaiting communication from recruiter
                </strong>
                <strong *ngIf="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'ACKNOWLEDGED'">
                  ✓ Application acknowledged by recruiter
                </strong>
                <strong *ngIf="getApplicationStatus(jobItem.job?.id || jobItem.id) === 'REJECTED'">
                  ✗ Application not selected
                </strong>
              </small>
            </div>
          </div>
          <button *ngIf="!getApplicationStatus(jobItem.job?.id || jobItem.id)" 
                  class="btn btn-outline-primary w-100" 
                  (click)="applyForJob(jobItem.job || jobItem)" 
                  [disabled]="!isLoggedIn || applyingJobs.has(jobItem.job?.id || jobItem.id)">
            <span *ngIf="!applyingJobs.has(jobItem.job?.id || jobItem.id)">Apply Now</span>
            <span *ngIf="applyingJobs.has(jobItem.job?.id || jobItem.id)">Applying...</span>
          </button>
          <div *ngIf="!isLoggedIn" class="alert alert-info mt-3" style="text-align: center; padding: 0.75rem;">
            <small>Please <a routerLink="/login" [queryParams]="{role: 'ROLE_CANDIDATE'}" style="color: var(--primary);">login</a> to apply for jobs</small>
          </div>
        </div>
      </div>
    </div>
  </div>
  `
})
export class JobListComponent implements OnInit {
  jobs: any[] = [];
  resumes: any[] = [];
  applications: any[] = [];
  isLoggedIn = false;
  applyingJobs = new Set<number>();

  constructor(
    private api: ApiService,
    private authService: AuthService
  ) {
    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = user !== null && user.role === 'ROLE_CANDIDATE';
      if (this.isLoggedIn) {
        this.loadResumes();
        this.loadApplications();
      }
    });
  }

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user && user.role === 'ROLE_CANDIDATE') {
      // Reload resumes when page loads (in case resume was just uploaded)
      this.loadResumes();
      // Load recommended jobs for candidates
      this.api.get('/jobs/recommended').subscribe({
        next: (res: any) => {
          this.jobs = Array.isArray(res) ? res : [];
        },
        error: (err) => {
          console.error('Error loading recommended jobs:', err);
          // Fallback to regular job list
          this.api.get('/jobs').subscribe((res: any) => { 
            this.jobs = res.content || []; 
          }, err => console.error(err));
        }
      });
    } else {
      // Load regular job list for non-candidates
      this.api.get('/jobs').subscribe((res: any) => { 
        this.jobs = res.content || []; 
      }, err => console.error(err));
    }
  }

  loadResumes() {
    console.log('Loading resumes...');
    this.api.get('/api/resume/my').subscribe({
      next: (res: any) => {
        console.log('Resumes response:', res);
        this.resumes = Array.isArray(res) ? res : [];
        console.log('Loaded resumes count:', this.resumes.length);
        if (this.resumes.length > 0) {
          console.log('First resume:', this.resumes[0]);
        }
      },
      error: (err) => {
        console.error('Error loading resumes:', err);
        console.error('Error details:', err.error, err.status, err.message);
        this.resumes = [];
      }
    });
  }

  loadApplications() {
    this.api.get('/applications/my').subscribe((res: any) => {
      this.applications = Array.isArray(res) ? res : [];
    }, err => {
      console.error('Error loading applications:', err);
      this.applications = [];
    });
  }

  getApplicationStatus(jobId: number): string | null {
    const app = this.applications.find(a => a.job?.id === jobId || a.application?.jobId === jobId);
    return app?.application?.status || null;
  }

  applyForJob(job: any) {
    if (!this.isLoggedIn) {
      alert('Please login as a candidate to apply for jobs');
      return;
    }

    // Reload resumes before checking (in case resume was just uploaded)
    if (this.resumes.length === 0) {
      this.loadResumes();
      // Wait a bit for the request to complete, then check again
      setTimeout(() => {
        if (this.resumes.length === 0) {
          alert('Please upload a resume first from your candidate dashboard before applying for jobs.');
          return;
        } else {
          // Retry applying with the loaded resume
          this.submitApplication(job);
        }
      }, 500);
      return;
    }

    this.submitApplication(job);
  }

  private submitApplication(job: any) {
    if (!job || !job.id) {
      alert('Invalid job information');
      return;
    }

    // Check if already applied
    if (this.getApplicationStatus(job.id)) {
      alert('You have already applied for this job.');
      return;
    }

    // Use the most recent resume (first in list, assuming sorted by date)
    const resume = this.resumes[0];
    
    if (!resume || !resume.id) {
      alert('Resume not found. Please upload a resume first.');
      this.loadResumes(); // Try reloading
      return;
    }
    
    this.applyingJobs.add(job.id);
    
    this.api.post('/applications/apply', {
      jobId: job.id,
      resumeId: resume.id
    }).subscribe({
      next: (res: any) => {
        this.applyingJobs.delete(job.id);
        alert('Application submitted successfully! Awaiting communication from the recruiter.');
        this.loadApplications(); // Refresh applications
        this.loadResumes(); // Refresh resumes in case of any updates
      },
      error: (err: any) => {
        this.applyingJobs.delete(job.id);
        let errorMsg = 'Failed to apply';
        if (err.error?.error) {
          errorMsg = err.error.error;
        } else if (err.error?.message) {
          errorMsg = err.error.message;
        } else if (err.message) {
          errorMsg = err.message;
        }
        alert('Application failed: ' + errorMsg);
        console.error('Application error:', err);
      }
    });
  }
}
