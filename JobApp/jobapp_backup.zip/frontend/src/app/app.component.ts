import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet, NavigationEnd } from '@angular/router';
import { ThemeService } from './services/theme.service';
import { AuthService, User } from './services/auth.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet],
  template: `
    <nav class="navbar navbar-expand-lg sticky-top fade-in">
      <div class="container">
        <a class="navbar-brand" routerLink="/">
          <span class="brand-icon">✨</span> JobPortal AI
        </a>
        <div class="d-flex gap-4 align-items-center">
          <a routerLink="/jobs" class="nav-link">Jobs</a>
          <a *ngIf="currentUser && currentUser.role === 'ROLE_CANDIDATE'" routerLink="/candidate" class="nav-link">My Dashboard</a>
          <a *ngIf="currentUser && currentUser.role === 'ROLE_RECRUITER'" routerLink="/recruiter" class="nav-link">My Dashboard</a>
          <div class="vr" style="opacity: 0.2" *ngIf="currentUser"></div>
          <div *ngIf="currentUser" class="d-flex gap-3 align-items-center">
            <div class="user-info">
              <div class="user-name">{{currentUser.name}}</div>
              <div class="user-role">{{currentUser.role === 'ROLE_RECRUITER' ? 'Recruiter' : 'Candidate'}}</div>
            </div>
            <button (click)="logout()" class="btn btn-sm btn-outline-primary">Logout</button>
          </div>
          <div *ngIf="!currentUser && !isLandingPage()" class="d-flex gap-2 align-items-center">
            <a routerLink="/login" class="btn btn-sm btn-outline-primary">Login</a>
            <a routerLink="/register" class="btn btn-sm btn-primary text-white">Register</a>
          </div>
          <div class="theme-toggle" (click)="toggleTheme()" title="Toggle theme">
            <div class="theme-toggle-slider">
              <span class="theme-icon">{{isDark ? '🌙' : '☀️'}}</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <main style="min-height: calc(100vh - 100px); padding: 3rem 0;">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    .navbar {
      padding: 1rem 0;
    }
    
    .brand-icon {
      font-size: 1.5rem;
      margin-right: 0.5rem;
    }
    
    .nav-link {
      text-decoration: none;
      color: var(--text-secondary);
      font-weight: 500;
      font-size: 0.9375rem;
      transition: color 0.2s ease;
      position: relative;
    }
    
    .nav-link::after {
      content: '';
      position: absolute;
      bottom: -4px;
      left: 0;
      width: 0;
      height: 2px;
      background: var(--primary);
      transition: width 0.3s ease;
    }
    
    .nav-link:hover {
      color: var(--primary);
    }
    
    .nav-link:hover::after {
      width: 100%;
    }
    
    .user-info {
      text-align: right;
      padding-right: 1rem;
    }
    
    .user-name {
      font-weight: 600;
      font-size: 0.9375rem;
      color: var(--text-primary);
      margin-bottom: 0.125rem;
    }
    
    .user-role {
      font-size: 0.75rem;
      color: var(--text-secondary);
      text-transform: capitalize;
    }
    
    .theme-toggle {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .theme-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    @media (max-width: 768px) {
      .user-info {
        display: none;
      }
    }
  `]
})
export class AppComponent implements OnInit, OnDestroy {
  isDark = false;
  currentUser: User | null = null;
  currentRoute = '';
  private userSubscription?: Subscription;
  private routeSubscription?: Subscription;

  constructor(
    private themeService: ThemeService,
    private authService: AuthService,
    private router: Router
  ) {
    this.themeService.isDark$.subscribe(isDark => this.isDark = isDark);
  }

  ngOnInit() {
    this.userSubscription = this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });

    // Track current route
    this.currentRoute = this.router.url;
    this.routeSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.url;
      });
  }

  ngOnDestroy() {
    this.userSubscription?.unsubscribe();
    this.routeSubscription?.unsubscribe();
  }

  isLandingPage(): boolean {
    return this.currentRoute === '/' || this.currentRoute === '';
  }

  toggleTheme() {
    this.themeService.toggleTheme();
  }

  logout() {
    this.authService.logout();
    // Navigate to home page after logout
    window.location.href = '/';
  }
}
