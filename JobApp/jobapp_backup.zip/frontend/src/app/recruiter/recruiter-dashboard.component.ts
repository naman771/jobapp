import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-recruiter-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
  <div class="container fade-in">
    <div style="text-align: center; margin-bottom: 4rem;">
      <h1 style="margin-bottom: 1rem;">Recruiter Dashboard</h1>
      <p class="text-secondary" style="font-size: 1.125rem;">Post jobs and manage applicants</p>
      <a routerLink="/jobs" class="btn btn-outline-primary" style="margin-top: 1rem;">View All Jobs</a>
    </div>

    <div class="row mb-5">
      <div class="col-12">
        <div class="card">
          <h3 style="margin-bottom: 0.5rem;">Post a New Job</h3>
          <p class="text-secondary" style="margin-bottom: 2.5rem;">Fill in the details to create a new job listing</p>
          <form (ngSubmit)="postJob()">
            <div class="row">
              <div class="col-md-4">
                <label class="form-label">Job Title</label>
                <input [(ngModel)]="title" name="title" placeholder="e.g. Senior Developer" required />
              </div>
              <div class="col-md-4">
                <label class="form-label">Company</label>
                <input [(ngModel)]="company" name="company" placeholder="e.g. Tech Corp" required />
              </div>
              <div class="col-md-4">
                <label class="form-label">Location</label>
                <input [(ngModel)]="location" name="location" placeholder="e.g. Remote, New York" required />
              </div>
            </div>
            <div>
              <label class="form-label">Required Skills</label>
              <input [(ngModel)]="skills" name="skills" placeholder="Java, Python, Spring Boot, React..." required />
            </div>
            <div>
              <label class="form-label">Job Description</label>
              <textarea [(ngModel)]="desc" name="desc" placeholder="Describe the role, responsibilities, and requirements..." rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Post Job</button>
          </form>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h3 style="margin-bottom: 0;">My Jobs</h3>
          <button (click)="loadMyJobs()" class="btn btn-sm btn-outline-primary">
            🔄 Refresh
          </button>
        </div>
        <div *ngIf="jobs.length === 0" class="alert alert-info">
          <p style="margin: 0;">You haven't posted any jobs yet.</p>
        </div>
        <div *ngFor="let job of jobs; let i = index" 
             class="card slide-up mb-3" 
             [style.animation-delay]="i * 0.1 + 's'"
             style="border-left: 4px solid transparent; transition: all 0.2s;" 
             [style.border-left-color]="selectedJob?.id === job.id ? 'var(--primary)' : 'transparent'"
             [style.background]="selectedJob?.id === job.id ? 'rgba(99, 102, 241, 0.05)' : 'var(--bg-elevated)'">
          <div class="d-flex justify-content-between align-items-start">
            <div (click)="viewApplicants(job)" style="cursor: pointer; flex-grow: 1;">
              <h4 style="margin-bottom: 0.5rem; font-size: 1.25rem;">{{job.title}}</h4>
              <div class="text-muted">{{job.company}} • {{job.location}}</div>
            </div>
            <button (click)="deleteJob(job.id, $event)" 
                    class="btn btn-sm btn-danger ms-2" 
                    [disabled]="deletingJobs.has(job.id)"
                    style="flex-shrink: 0; padding: 0.5rem 0.75rem;"
                    title="Delete this job">
              <span *ngIf="!deletingJobs.has(job.id)">🗑️ Delete</span>
              <span *ngIf="deletingJobs.has(job.id)">Deleting...</span>
            </button>
          </div>
        </div>
      </div>
      <div class="col-md-8" *ngIf="selectedJob">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h3 style="margin-bottom: 0;">Applicants for <span class="text-primary">{{selectedJob.title}}</span></h3>
          <button (click)="loadApplicants(selectedJob)" class="btn btn-sm btn-outline-primary">
            🔄 Refresh
          </button>
        </div>
        <div *ngIf="applicants.length === 0" class="alert alert-info">
          <p style="margin: 0;">No applicants yet. Share your job listing to attract candidates!</p>
        </div>
        <div *ngFor="let app of applicants; let i = index" class="card slide-up mb-4" [style.animation-delay]="i * 0.1 + 's'">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="flex-grow-1">
              <h4 style="margin-bottom: 0.5rem;">{{app.user?.name || 'Candidate'}}</h4>
              <div class="text-muted mb-2">{{app.user?.email}}</div>
              <div>
                <span class="badge" 
                      [class.bg-info]="app.application.status === 'APPLIED'"
                      [class.bg-success]="app.application.status === 'ACKNOWLEDGED'"
                      [class.bg-danger]="app.application.status === 'REJECTED'"
                      style="font-size: 0.875rem; padding: 0.5rem 1rem;">
                  {{getStatusLabel(app.application.status)}}
                </span>
              </div>
            </div>
            <span class="badge bg-primary shadow-sm" style="font-size: 1rem; padding: 0.75rem 1.25rem;">
              Match: {{app.application.matchScore | number:'1.0-0'}}%
            </span>
          </div>
          <hr style="margin: 2rem 0; border: none; border-top: 1px solid var(--border-color); opacity: 0.3;">
          <div class="row mb-4">
            <div class="col-md-6" *ngIf="app.analysis.matched.length > 0">
              <div style="margin-bottom: 1rem;">
                <div class="text-success fw-bold small" style="margin-bottom: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em;">Matched Skills</div>
                <div class="d-flex flex-wrap gap-2">
                  <span *ngFor="let s of app.analysis.matched" class="badge bg-success bg-opacity-75" style="padding: 0.5rem 1rem;">{{s}}</span>
                </div>
              </div>
            </div>
            <div class="col-md-6" *ngIf="app.analysis.missing.length > 0">
              <div style="margin-bottom: 1rem;">
                <div class="text-danger fw-bold small" style="margin-bottom: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em;">Missing Skills</div>
                <div class="d-flex flex-wrap gap-2">
                  <span *ngFor="let s of app.analysis.missing" class="badge bg-danger bg-opacity-75" style="padding: 0.5rem 1rem;">{{s}}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex justify-content-between align-items-center">
            <a [href]="getFileUrl(app.resume?.fileUrl)" target="_blank" class="btn btn-outline-primary">View Resume</a>
            <div *ngIf="app.application.status === 'APPLIED'" class="d-flex gap-2">
              <button (click)="acknowledgeApplication(app.application.id)" class="btn btn-success">
                ✓ Acknowledge
              </button>
              <button (click)="rejectApplication(app.application.id)" class="btn btn-danger">
                ✗ Reject
              </button>
            </div>
            <div *ngIf="app.application.status !== 'APPLIED'" class="text-muted small">
              <em>Status: {{getStatusLabel(app.application.status)}}</em>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  `
})
export class RecruiterDashboardComponent implements OnInit {
  title = ''; company = ''; location = ''; skills = ''; desc = ''; posted: any;
  jobs: any[] = [];
  selectedJob: any = null;
  applicants: any[] = [];
  deletingJobs = new Set<number>();

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.loadMyJobs();
  }

  loadMyJobs() {
    console.log('Loading my jobs...');
    this.api.get('/jobs/my').subscribe({
      next: (r: any) => {
        console.log('Jobs response:', r);
        this.jobs = Array.isArray(r) ? r : [];
        console.log('Loaded jobs count:', this.jobs.length);
      },
      error: (err) => {
        console.error('Error loading jobs:', err);
        console.error('Error details:', err.error, err.status, err.message);
        this.jobs = [];
        alert('Failed to load your jobs. Please try refreshing the page.');
      }
    });
  }

  postJob() {
    // Validate all required fields
    const title = this.title?.trim();
    const company = this.company?.trim();
    const location = this.location?.trim();
    const skills = this.skills?.trim();
    const description = this.desc?.trim();

    // Check if any required field is empty
    if (!title) {
      alert('Please enter a job title.');
      return;
    }
    if (!company) {
      alert('Please enter a company name.');
      return;
    }
    if (!location) {
      alert('Please enter a job location.');
      return;
    }
    if (!skills) {
      alert('Please enter required skills.');
      return;
    }
    if (!description) {
      alert('Please enter a job description.');
      return;
    }

    // Additional validation: check minimum length
    if (title.length < 3) {
      alert('Job title must be at least 3 characters long.');
      return;
    }
    if (description.length < 20) {
      alert('Job description must be at least 20 characters long.');
      return;
    }
    if (skills.split(',').filter((s: string) => s.trim().length > 0).length === 0) {
      alert('Please enter at least one valid skill.');
      return;
    }

    // All validations passed, proceed with posting
    this.api.post('/jobs', { 
      title: title, 
      company: company, 
      location: location, 
      skills: skills, 
      description: description,
      salaryRange: '',
      jobType: 'Full-time'
    })
      .subscribe({
        next: (r) => {
          console.log('Job posted successfully:', r);
          this.posted = r;
          alert('Job posted successfully!');
          this.loadMyJobs(); // Reload jobs list
          this.title = ''; 
          this.company = ''; 
          this.location = ''; 
          this.skills = ''; 
          this.desc = '';
        },
        error: (e) => {
          console.error('Error posting job:', e);
          alert('Post failed: ' + (e.error?.message || e.message || 'Unknown error'));
        }
      });
  }

  viewApplicants(job: any) {
    this.selectedJob = job;
    this.loadApplicants(job);
  }

  loadApplicants(job: any) {
    if (!job || !job.id) {
      console.error('Invalid job object');
      this.applicants = [];
      return;
    }
    
    this.api.get(`/applications/job/${job.id}`).subscribe({
      next: (apps: any) => {
        this.applicants = (Array.isArray(apps) ? apps : []).map((app: any) => {
          if (app && app.resume) {
            app.analysis = this.analyzeSkills(job.skills || '', app.resume?.parsedJson || '');
          } else {
            app.analysis = { matched: [], missing: [] };
          }
          return app;
        });
      },
      error: (err) => {
        console.error('Error loading applicants:', err);
        this.applicants = [];
        alert('Failed to load applicants: ' + (err.error?.error || err.message || 'Unknown error'));
      }
    });
  }

  analyzeSkills(jobSkills: string, resumeJson: string) {
    if (!jobSkills || !resumeJson) return { matched: [], missing: [] };

    const required = jobSkills.split(',').map(s => s.trim().toLowerCase()).filter(s => s);
    let parsed: any = {};
    try { parsed = JSON.parse(resumeJson); } catch (e) { }

    const candidateSkills = (parsed.skills || []).map((s: string) => s.toLowerCase());

    const matched = required.filter(r => candidateSkills.includes(r));
    const missing = required.filter(r => !candidateSkills.includes(r));

    return { matched, missing };
  }

  getFileUrl(path: string) {
    if (!path) return '#';
    const filename = path.split('/').pop();
    return `http://localhost:8080/api/resume/download/${filename}`;
  }

  getStatusLabel(status: string): string {
    switch(status) {
      case 'APPLIED': return 'New Application';
      case 'ACKNOWLEDGED': return 'Acknowledged';
      case 'REJECTED': return 'Rejected';
      default: return status;
    }
  }

  acknowledgeApplication(applicationId: number) {
    if (!confirm('Are you sure you want to acknowledge this application?')) {
      return;
    }
    
    this.api.post(`/applications/${applicationId}/acknowledge`, {}).subscribe({
      next: (res: any) => {
        alert('Application acknowledged successfully. The candidate will be notified.');
        this.loadApplicants(this.selectedJob);
      },
      error: (err: any) => {
        alert('Failed to acknowledge application: ' + (err.error?.error || err.message));
      }
    });
  }

  rejectApplication(applicationId: number) {
    if (!confirm('Are you sure you want to reject this application? The candidate will be notified.')) {
      return;
    }
    
    this.api.post(`/applications/${applicationId}/reject`, {}).subscribe({
      next: (res: any) => {
        alert('Application rejected. The candidate will be notified.');
        this.loadApplicants(this.selectedJob);
      },
      error: (err: any) => {
        alert('Failed to reject application: ' + (err.error?.error || err.message));
      }
    });
  }

  deleteJob(jobId: number, event: Event) {
    event.stopPropagation(); // Prevent triggering viewApplicants
    
    if (!confirm('Are you sure you want to delete this job? All applications for this job will also be deleted. This action cannot be undone.')) {
      return;
    }

    if (!jobId) {
      alert('Invalid job ID');
      return;
    }

    this.deletingJobs.add(jobId);

    this.api.delete(`/jobs/${jobId}`).subscribe({
      next: (res: any) => {
        this.deletingJobs.delete(jobId);
        alert('Job deleted successfully.');
        // If deleted job was selected, clear selection
        if (this.selectedJob?.id === jobId) {
          this.selectedJob = null;
          this.applicants = [];
        }
        // Reload jobs list
        this.loadMyJobs();
      },
      error: (err: any) => {
        this.deletingJobs.delete(jobId);
        let errorMsg = 'Failed to delete job';
        if (err.error?.error) {
          errorMsg = err.error.error;
        } else if (err.error?.message) {
          errorMsg = err.error.message;
        } else if (err.message) {
          errorMsg = err.message;
        }
        alert('Delete failed: ' + errorMsg);
      }
    });
  }
}
