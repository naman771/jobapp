import { Routes } from '@angular/router';

import { JobListComponent } from './job-list/job-list.component';
import { LandingComponent } from './auth/landing.component';
import { LoginComponent } from './auth/login.component';
import { RegisterComponent } from './auth/register.component';
import { CandidateDashboardComponent } from './candidate/candidate-dashboard.component';
import { RecruiterDashboardComponent } from './recruiter/recruiter-dashboard.component';

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'jobs', component: JobListComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'candidate', component: CandidateDashboardComponent },
  { path: 'recruiter', component: RecruiterDashboardComponent }
];
