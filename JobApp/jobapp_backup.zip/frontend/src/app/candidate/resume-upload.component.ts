import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-resume-upload',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div>
    <h3 style="margin-bottom: 0.5rem;">Upload Your Resume</h3>
    <p class="text-secondary" style="margin-bottom: 2rem;">Upload your resume in PDF or DOCX format to apply for jobs</p>
    <div style="margin-bottom: 2rem;">
      <label class="form-label">Select Resume File</label>
      <input type="file" (change)="onFile($event)" accept=".pdf,.doc,.docx" style="padding: 1.5rem; border: 2px dashed var(--border-color); cursor: pointer; transition: all 0.2s;" 
             [style.border-color]="file ? 'var(--primary)' : 'var(--border-color)'"
             [style.background]="file ? 'rgba(99, 102, 241, 0.05)' : 'transparent'" />
      <p *ngIf="file" class="text-primary small" style="margin-top: 0.75rem; margin-bottom: 0;">
        ✓ Selected: {{file.name}}
      </p>
    </div>
    <button (click)="upload()" class="btn btn-primary w-100" [disabled]="!file">Upload Resume</button>
    <div *ngIf="resp" class="alert alert-info" style="margin-top: 2rem;">
      <p style="margin: 0;"><strong>Success!</strong> Your resume has been uploaded and processed.</p>
    </div>
  </div>
  `
})
export class ResumeUploadComponent {
  @Output() resumeUploaded = new EventEmitter<void>();
  file: File | null = null;
  resp: any;
  constructor(private api: ApiService) {}
  onFile(ev: any) { this.file = ev.target.files[0]; }
  upload() {
    if (!this.file) return alert('Choose file');
    const fd = new FormData(); fd.append('file', this.file);
    this.api.upload('/api/resume/upload', fd).subscribe({
      next: (r) => { 
        this.resp = r; 
        alert('Resume uploaded successfully');
        this.resumeUploaded.emit(); // Notify parent component
        this.file = null; // Reset file input
      }, 
      error: (e) => alert('Upload failed: ' + (e.error?.message || e.message))
    });
  }
}
