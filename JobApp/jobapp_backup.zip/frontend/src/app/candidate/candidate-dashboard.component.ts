import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ResumeUploadComponent } from './resume-upload.component';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [CommonModule, ResumeUploadComponent, RouterLink],
  template: `
  <div class="container">
    <div style="text-align: center; margin-bottom: 3rem;">
      <h1 style="margin-bottom: 1rem;">Candidate Dashboard</h1>
      <p class="text-secondary" style="font-size: 1.125rem;">Manage your profile and applications</p>
      <a routerLink="/jobs" class="btn btn-primary" style="margin-top: 1rem;">Browse Available Jobs</a>
    </div>
    <div class="row">
      <div class="col-md-8" style="margin: 0 auto;">
        <div class="card fade-in">
          <app-resume-upload (resumeUploaded)="onResumeUploaded()"></app-resume-upload>
        </div>
      </div>
    </div>
    
    <div class="row mt-5" *ngIf="applications.length > 0">
      <div class="col-12">
        <div class="card fade-in">
          <h3 style="margin-bottom: 1.5rem;">My Applications</h3>
          <div *ngFor="let app of applications; let i = index" class="mb-4" [style.border-bottom]="i < applications.length - 1 ? '1px solid var(--border-color)' : 'none'" [style.padding-bottom]="i < applications.length - 1 ? '1.5rem' : '0'">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div class="flex-grow-1">
                <h4 style="margin-bottom: 0.5rem;">{{app.job?.title || 'Job Application'}}</h4>
                <div class="text-muted mb-2">
                  <strong>{{app.job?.company}}</strong> • {{app.job?.location}}
                </div>
                <div class="mb-2">
                  <span class="badge" 
                        [class.bg-info]="app.application.status === 'APPLIED'"
                        [class.bg-success]="app.application.status === 'ACKNOWLEDGED'"
                        [class.bg-danger]="app.application.status === 'REJECTED'"
                        style="font-size: 0.875rem; padding: 0.5rem 1rem;">
                    {{getStatusMessage(app.application.status)}}
                  </span>
                  <span class="badge bg-primary bg-opacity-10 text-primary ms-2" style="font-size: 0.875rem; padding: 0.5rem 1rem;">
                    Match: {{app.application.matchScore | number:'1.0-0'}}%
                  </span>
                </div>
              </div>
            </div>
            <div *ngIf="app.application.status === 'APPLIED'" class="alert alert-info" style="margin: 0; padding: 1rem;">
              <p style="margin: 0; font-size: 0.9375rem;">
                <strong>⏳ Awaiting Communication:</strong> Your application has been submitted successfully. 
                We are waiting for the recruiter to review and respond to your application.
              </p>
            </div>
            <div *ngIf="app.application.status === 'ACKNOWLEDGED'" class="alert alert-success" style="margin: 0; padding: 1rem;">
              <p style="margin: 0; font-size: 0.9375rem;">
                <strong>✓ Application Acknowledged:</strong> The recruiter has reviewed and acknowledged your application. 
                You may be contacted for further steps in the hiring process.
              </p>
            </div>
            <div *ngIf="app.application.status === 'REJECTED'" class="alert alert-danger" style="margin: 0; padding: 1rem;">
              <p style="margin: 0; font-size: 0.9375rem;">
                <strong>✗ Application Not Selected:</strong> Unfortunately, your application was not selected for this position. 
                Don't be discouraged - keep applying to other opportunities that match your skills.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row mt-5" *ngIf="applications.length === 0">
      <div class="col-md-8" style="margin: 0 auto;">
        <div class="card fade-in" style="text-align: center;">
          <p class="text-secondary" style="margin: 0; line-height: 1.7;">
            Upload your resume to get started. Once uploaded, you can browse available jobs and apply with your resume. 
            Your applications will be tracked here.
          </p>
        </div>
      </div>
    </div>
  </div>
  `
})
export class CandidateDashboardComponent implements OnInit {
  applications: any[] = [];

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.loadApplications();
  }

  loadApplications() {
    this.api.get('/applications/my').subscribe({
      next: (res: any) => {
        this.applications = Array.isArray(res) ? res : [];
      },
      error: (err) => {
        console.error('Error loading applications:', err);
        this.applications = [];
      }
    });
  }

  getStatusMessage(status: string): string {
    switch(status) {
      case 'APPLIED': return 'Awaiting Response';
      case 'ACKNOWLEDGED': return 'Acknowledged';
      case 'REJECTED': return 'Not Selected';
      default: return status;
    }
  }

  onResumeUploaded() {
    // Resume was uploaded, applications might need refresh
    this.loadApplications();
  }
}
