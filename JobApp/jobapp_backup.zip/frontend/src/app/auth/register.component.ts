import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
  <div class="container" style="max-width: 520px; margin: 0 auto;">
    <div class="card fade-in">
      <div style="text-align: center; margin-bottom: 2.5rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">{{roleIcon}}</div>
        <h2 style="margin-bottom: 0.5rem;">Create {{roleLabel}} Account</h2>
        <p class="text-secondary" style="margin-bottom: 0;">{{roleDescription}}</p>
      </div>
      <form (ngSubmit)="doRegister()">
        <div>
          <label class="form-label">Full Name</label>
          <input name="name" [(ngModel)]="name" placeholder="John Doe" required />
        </div>
        <div>
          <label class="form-label">Email Address</label>
          <input name="email" [(ngModel)]="email" type="email" placeholder="you@example.com" required />
        </div>
        <div>
          <label class="form-label">Password</label>
          <input name="password" [(ngModel)]="password" type="password" placeholder="Create a strong password" required />
        </div>
        <input type="hidden" [(ngModel)]="role" name="role" />
        <button type="submit" class="btn btn-primary w-100" style="margin-top: 0.5rem;">Create Account</button>
      </form>
      <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color);">
        <p class="text-secondary small">Already have an account? <a [routerLink]="['/login']" [queryParams]="{role: role}" style="color: var(--primary); text-decoration: none; font-weight: 600;">Sign in</a></p>
        <p class="text-secondary small" style="margin-top: 1rem;">
          <a routerLink="/" style="color: var(--text-secondary); text-decoration: none;">← Back to home</a>
        </p>
      </div>
    </div>
  </div>
  `
})
export class RegisterComponent implements OnInit {
  name=''; email=''; password=''; role='ROLE_CANDIDATE';
  roleLabel: string = 'Candidate';
  roleIcon: string = '👤';
  roleDescription: string = 'Join us to find your dream job';

  constructor(
    private api: ApiService, 
    private authService: AuthService, 
    private router: Router,
    private route: ActivatedRoute
  ){}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.role = params['role'] || 'ROLE_CANDIDATE';
      if (this.role === 'ROLE_RECRUITER') {
        this.roleLabel = 'Recruiter';
        this.roleIcon = '💼';
        this.roleDescription = 'Start hiring the best talent for your company';
      } else {
        this.roleLabel = 'Candidate';
        this.roleIcon = '👤';
        this.roleDescription = 'Join us to find your dream job';
      }
    });
  }
  doRegister(){
    if (!this.name || !this.email || !this.password) {
      alert('Please fill in all fields');
      return;
    }

    console.log('Attempting registration with:', { name: this.name, email: this.email, role: this.role });
    
    this.api.post('/auth/register', { name: this.name, email: this.email, password: this.password, role: this.role})
      .subscribe({
        next: (res) => { 
          console.log('Registration response:', res);
          
          // Auto-login after registration
          console.log('Attempting auto-login...');
          this.api.post('/auth/login', { email: this.email, password: this.password })
            .subscribe({
              next: (loginRes: any) => {
                console.log('Auto-login response:', loginRes);
                
                if (!loginRes || !loginRes.token || !loginRes.user) {
                  alert('Registration successful! Please login manually.');
                  this.router.navigate(['/login'], { queryParams: { role: this.role } });
                  return;
                }

                const token = loginRes.token;
                const user = loginRes.user;
                this.authService.setUser(user, token);
                
                // Navigate based on role
                if (user.role === 'ROLE_RECRUITER') {
                  this.router.navigate(['/recruiter']);
                } else {
                  this.router.navigate(['/candidate']);
                }
              },
              error: (err: any) => {
                console.error('Auto-login error:', err);
                // If auto-login fails, redirect to login page
                alert('Registration successful! Please login.');
                this.router.navigate(['/login'], { queryParams: { role: this.role } });
              }
            });
        },
        error: (err: any) => {
          console.error('Registration error:', err);
          let errorMsg = 'Registration failed';
          
          if (err.errorMessage) {
            errorMsg = err.errorMessage;
          } else if (err.error) {
            if (typeof err.error === 'string') {
              errorMsg = err.error;
            } else if (err.error.error) {
              errorMsg = err.error.error;
            } else if (err.error.message) {
              errorMsg = err.error.message;
            }
          } else if (err.message) {
            errorMsg = err.message;
          }
          
          alert('Register failed: ' + errorMsg);
        }
      });
  }
}
