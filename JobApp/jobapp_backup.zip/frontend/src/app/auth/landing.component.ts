import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="landing-container">
      <div class="container" style="max-width: 1000px; margin: 0 auto;">
        <div class="hero-section fade-in">
          <h1 style="font-size: 3rem; margin-bottom: 1rem; text-align: center;">
            <span class="brand-icon">✨</span> JobPortal AI
          </h1>
          <p class="text-secondary" style="font-size: 1.25rem; text-align: center; margin-bottom: 4rem; max-width: 600px; margin-left: auto; margin-right: auto;">
            Connect talent with opportunity. Whether you're looking for your next career move or searching for the perfect candidate.
          </p>
        </div>

        <div class="role-selection fade-in" style="animation-delay: 0.2s;">
          <h2 style="text-align: center; margin-bottom: 3rem; font-size: 2rem;">I am a...</h2>
          <div class="row">
            <div class="col-md-6 mb-4">
              <div class="role-card card" (click)="selectRole('ROLE_CANDIDATE')" [class.selected]="selectedRole === 'ROLE_CANDIDATE'">
                <div style="font-size: 4rem; margin-bottom: 1.5rem;">👤</div>
                <h3 style="margin-bottom: 1rem;">Candidate</h3>
                <p class="text-secondary" style="margin-bottom: 2rem; line-height: 1.7;">
                  Looking for your next opportunity? Browse jobs, upload your resume, and apply to positions that match your skills.
                </p>
                <div class="role-features">
                  <div class="feature-item">✓ Browse available jobs</div>
                  <div class="feature-item">✓ Upload and manage resume</div>
                  <div class="feature-item">✓ Apply to positions</div>
                  <div class="feature-item">✓ Track applications</div>
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-4">
              <div class="role-card card" (click)="selectRole('ROLE_RECRUITER')" [class.selected]="selectedRole === 'ROLE_RECRUITER'">
                <div style="font-size: 4rem; margin-bottom: 1.5rem;">💼</div>
                <h3 style="margin-bottom: 1rem;">Recruiter</h3>
                <p class="text-secondary" style="margin-bottom: 2rem; line-height: 1.7;">
                  Hiring talent? Post job listings, review applications, and find the perfect candidates with AI-powered matching.
                </p>
                <div class="role-features">
                  <div class="feature-item">✓ Post job listings</div>
                  <div class="feature-item">✓ Review applications</div>
                  <div class="feature-item">✓ AI-powered candidate matching</div>
                  <div class="feature-item">✓ Manage job postings</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="auth-actions fade-in" style="animation-delay: 0.4s; text-align: center; margin-top: 4rem;" *ngIf="selectedRole">
          <div style="margin-bottom: 2rem;">
            <h3 style="margin-bottom: 1rem;">Get Started</h3>
            <p class="text-secondary">Choose an option below to continue</p>
          </div>
          <div class="d-flex gap-3 justify-content-center" style="flex-wrap: wrap;">
            <a [routerLink]="['/login']" [queryParams]="{role: selectedRole}" class="btn btn-outline-primary btn-lg">
              Login
            </a>
            <a [routerLink]="['/register']" [queryParams]="{role: selectedRole}" class="btn btn-primary btn-lg text-white">
              Register
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .landing-container {
      min-height: 100vh;
      padding: 4rem 0;
      background: var(--bg-secondary);
    }

    .hero-section {
      margin-bottom: 4rem;
    }

    .role-card {
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      height: 100%;
      position: relative;
    }

    .role-card:hover {
      transform: translateY(-8px);
      border-color: var(--primary);
    }

    .role-card.selected {
      border-color: var(--primary);
      border-width: 3px;
      background: rgba(99, 102, 241, 0.05);
    }

    .role-card.selected::before {
      content: '✓';
      position: absolute;
      top: 1rem;
      right: 1rem;
      width: 32px;
      height: 32px;
      background: var(--primary);
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 1.25rem;
    }

    .role-features {
      text-align: left;
      margin-top: 2rem;
    }

    .feature-item {
      padding: 0.75rem 0;
      color: var(--text-secondary);
      border-bottom: 1px solid var(--border-color);
    }

    .feature-item:last-child {
      border-bottom: none;
    }

    .btn-lg {
      padding: 1.25rem 2.5rem;
      font-size: 1.125rem;
      min-height: 56px;
    }

    @media (max-width: 768px) {
      .landing-container {
        padding: 2rem 0;
      }

      .hero-section h1 {
        font-size: 2rem !important;
      }

      .role-selection h2 {
        font-size: 1.5rem !important;
      }
    }
  `]
})
export class LandingComponent implements OnInit {
  selectedRole: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    // If user is already logged in, redirect to their dashboard
    if (this.authService.isAuthenticated()) {
      const user = this.authService.getCurrentUser();
      if (user?.role === 'ROLE_RECRUITER') {
        this.router.navigate(['/recruiter']);
      } else if (user?.role === 'ROLE_CANDIDATE') {
        this.router.navigate(['/candidate']);
      }
    }
  }

  selectRole(role: string) {
    this.selectedRole = role;
  }
}

