import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
  <div class="container" style="max-width: 480px; margin: 0 auto;">
    <div class="card fade-in">
      <div style="text-align: center; margin-bottom: 2.5rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">{{roleIcon}}</div>
        <h2 style="margin-bottom: 0.5rem;">Welcome Back, {{roleLabel}}</h2>
        <p class="text-secondary" style="margin-bottom: 0;">Sign in to your {{roleLabel.toLowerCase()}} account</p>
      </div>
      <form (ngSubmit)="doLogin()">
        <div>
          <label class="form-label">Email Address</label>
          <input name="email" [(ngModel)]="email" type="email" placeholder="you@example.com" required />
        </div>
        <div>
          <label class="form-label">Password</label>
          <input name="password" [(ngModel)]="password" type="password" placeholder="Enter your password" required />
        </div>
        <button type="submit" class="btn btn-primary w-100" style="margin-top: 0.5rem;" [disabled]="isLoading">
          <span *ngIf="!isLoading">Sign In</span>
          <span *ngIf="isLoading">Signing in...</span>
        </button>
      </form>
      <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border-color);">
        <p class="text-secondary small">Don't have an account? <a [routerLink]="['/register']" [queryParams]="{role: selectedRole}" style="color: var(--primary); text-decoration: none; font-weight: 600;">Sign up</a></p>
        <p class="text-secondary small" style="margin-top: 1rem;">
          <a routerLink="/" style="color: var(--text-secondary); text-decoration: none;">← Back to home</a>
        </p>
      </div>
    </div>
  </div>
  `
})
export class LoginComponent implements OnInit {
  email = '';
  password = '';
  selectedRole: string = '';
  roleLabel: string = 'User';
  roleIcon: string = '👋';
  isLoading = false;

  constructor(
    private api: ApiService, 
    private authService: AuthService, 
    private router: Router,
    private route: ActivatedRoute
  ){}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.selectedRole = params['role'] || '';
      if (this.selectedRole === 'ROLE_RECRUITER') {
        this.roleLabel = 'Recruiter';
        this.roleIcon = '💼';
      } else if (this.selectedRole === 'ROLE_CANDIDATE') {
        this.roleLabel = 'Candidate';
        this.roleIcon = '👤';
      } else {
        this.roleLabel = 'User';
        this.roleIcon = '👋';
      }
    });
  }
  doLogin(){
    if (!this.email || !this.password) {
      alert('Please enter both email and password');
      return;
    }

    this.isLoading = true;
    console.log('Attempting login with:', { email: this.email });
    
    this.api.post('/auth/login', { email: this.email, password: this.password })
      .subscribe({
        next: (res: any) => { 
          this.isLoading = false;
          console.log('=== LOGIN RESPONSE DEBUG ===');
          console.log('Raw response:', res);
          console.log('Response type:', typeof res);
          console.log('Is array?', Array.isArray(res));
          console.log('Response keys:', res ? Object.keys(res) : 'null');
          console.log('Full JSON:', JSON.stringify(res, null, 2));
          console.log('===========================');
          
          if (!res) {
            alert('Login failed: No response from server');
            return;
          }

          // Try multiple possible response structures
          let token: string | null = null;
          let user: any = null;

          // Check direct properties
          if (res.token) token = res.token;
          if (res.user) user = res.user;

          // Check nested structures
          if (!token && res.data) {
            token = res.data.token;
            user = res.data.user;
          }

          if (!token && res.body) {
            token = res.body.token;
            user = res.body.user;
          }

          // Check if response is the token itself (old format)
          if (!token && typeof res === 'string') {
            token = res;
          }

          // If we have token but no user, try to fetch user info
          if (token && !user) {
            console.log('Token found but no user. Fetching user info...');
            localStorage.setItem('token', token);
            this.authService.fetchCurrentUser().subscribe({
              next: (userRes: any) => {
                console.log('Fetched user info:', userRes);
                if (userRes) {
                  // Validate role matches the selected role
                  if (this.selectedRole && userRes.role !== this.selectedRole) {
                    const expectedRole = this.selectedRole === 'ROLE_RECRUITER' ? 'Recruiter' : 'Candidate';
                    const actualRole = userRes.role === 'ROLE_RECRUITER' ? 'Recruiter' : 'Candidate';
                    localStorage.removeItem('token');
                    alert(`Role mismatch! You are registered as a ${actualRole}, but you selected ${expectedRole}. Please select the correct role.`);
                    return;
                  }
                  
                  this.authService.setUser(userRes, token!);
                  if (userRes.role === 'ROLE_RECRUITER') {
                    this.router.navigate(['/recruiter']);
                  } else {
                    this.router.navigate(['/candidate']);
                  }
                } else {
                  alert('Login successful but user info not available.');
                }
              },
              error: (err) => {
                console.error('Error fetching user info:', err);
                localStorage.removeItem('token');
                alert('Login successful but could not fetch user info. Please refresh the page.');
                this.router.navigate(['/']);
              }
            });
            return;
          }
          
          if (!token) {
            console.error('Token not found. Full response structure:', JSON.stringify(res, null, 2));
            alert('Login failed: Token not found in response. Check browser console (F12) for details.');
            return;
          }
          
          if (!user) {
            console.error('User not found. Full response structure:', JSON.stringify(res, null, 2));
            alert('Login failed: User info not found in response. Check browser console (F12) for details.');
            return;
          }

          console.log('Successfully parsed - Token:', token ? 'Found' : 'Missing', 'User:', user ? 'Found' : 'Missing');
          console.log('User object:', user);
          
          // Validate role matches the selected role
          if (this.selectedRole && user.role !== this.selectedRole) {
            const expectedRole = this.selectedRole === 'ROLE_RECRUITER' ? 'Recruiter' : 'Candidate';
            const actualRole = user.role === 'ROLE_RECRUITER' ? 'Recruiter' : 'Candidate';
            alert(`Role mismatch! You are registered as a ${actualRole}, but you selected ${expectedRole}. Please select the correct role.`);
            return;
          }
          
          this.authService.setUser(user, token);
          
          // Navigate based on role
          if (user.role === 'ROLE_RECRUITER') {
            this.router.navigate(['/recruiter']);
          } else {
            this.router.navigate(['/candidate']);
          }
        },
        error: (err: any) => {
          this.isLoading = false;
          console.error('Login error:', err);
          let errorMsg = 'Login failed';
          
          if (err.errorMessage) {
            errorMsg = err.errorMessage;
          } else if (err.error) {
            if (typeof err.error === 'string') {
              errorMsg = err.error;
            } else if (err.error.error) {
              errorMsg = err.error.error;
            } else if (err.error.message) {
              errorMsg = err.error.message;
            }
          } else if (err.message) {
            errorMsg = err.message;
          }
          
          alert('Login failed: ' + errorMsg);
        }
      });
  }
}
