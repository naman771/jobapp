import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ThemeService {
    private isDark = new BehaviorSubject<boolean>(false);
    isDark$ = this.isDark.asObservable();

    constructor() {
        // Check if we're in browser environment
        if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
            // Check localStorage or system preference
            const savedTheme = localStorage.getItem('theme');
            const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

            const isDarkMode = savedTheme === 'dark' || (!savedTheme && prefersDark);
            this.setTheme(isDarkMode);
        }
    }

    toggleTheme() {
        this.setTheme(!this.isDark.value);
    }

    setTheme(isDark: boolean) {
        this.isDark.next(isDark);

        if (typeof document !== 'undefined') {
            document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
        }

        if (typeof localStorage !== 'undefined') {
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        }
    }

    getCurrentTheme(): boolean {
        return this.isDark.value;
    }
}
