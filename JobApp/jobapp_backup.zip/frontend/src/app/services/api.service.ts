import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class ApiService {
  private base = environment.apiBase;
  constructor(private http: HttpClient) {}

  post(path: string, body: any): Observable<any> { 
    return this.http.post(this.base + path, body).pipe(
      catchError(this.handleError)
    );
  }
  
  get(path: string, params?: any): Observable<any> { 
    return this.http.get(this.base + path, { params }).pipe(
      catchError(this.handleError)
    );
  }
  
  upload(path: string, formData: FormData): Observable<any> { 
    return this.http.post(this.base + path, formData).pipe(
      catchError(this.handleError)
    );
  }

  delete(path: string): Observable<any> {
    return this.http.delete(this.base + path).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      if (error.error) {
        if (typeof error.error === 'string') {
          errorMessage = error.error;
        } else if (error.error.error) {
          errorMessage = error.error.error;
        } else if (error.error.message) {
          errorMessage = error.error.message;
        }
      }
    }
    return throwError(() => ({ ...error, errorMessage }));
  }
}
